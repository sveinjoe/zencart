<?php
/**
 * @copyright Copyright 2003-2022 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: DrByte 2020 Jul 10 Modified in v1.5.8-alpha $
 */
// get time zone settings from catalog-side file
include (DIR_FS_CATALOG . '/includes/extra_configures/set_time_zone.php');

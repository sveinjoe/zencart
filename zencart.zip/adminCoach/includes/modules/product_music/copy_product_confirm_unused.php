<?php
/*
 * No longer needed for Zen Cart 1.5.8 and later.
 *
 * See /admin/includes/classes/observers/auto.ProductMusicObserver.php for
 * the updated handling.
 */

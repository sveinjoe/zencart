<?php
/**
 *  zca_bootstrap_colors.php
 *
 * @copyright Copyright 2003-2018 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version Author: rbarbour (ZCAdditions.com)  7/01/2018 06:00 AM Modified ZCA-BS-COLORS
 *
 */

define('FILENAME_ZCA_BOOTSTRAP_COLORS','zca_bootstrap_colors');

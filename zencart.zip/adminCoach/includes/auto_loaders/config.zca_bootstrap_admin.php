<?php
// -----
// Load the admin template-change "watcher" for the ZCAdditions bootstrap template.
//
$autoLoadConfig[200][] = array(
    'autoType' => 'init_script',
    'loadFile' => 'init_zca_bootstrap_template_admin.php'
);

<?php

return [
    'pluginVersion' => 'v3.0.2',
    'pluginName' => 'Display logs',
    'pluginDescription' => 'Display and manage Zen Cart log files.',
    'pluginAuthor' => 'Vinos de Frutas Tropicales (lat9)',
    'pluginId' => 1583, // ID from Zen Cart forum
    'zcVersions' => ['v158'],
    'changelog' => '', // online URL (eg github release tag page, or changelog file there) or local filename only, ie: changelog.txt (in same dir as this manifest file)
    'github_repo' => '', // url
    'pluginGroups' => [],
];

<?php 
/**
 * Mod List by That Software Guy 
 * @copyright That Software Guy, Inc., 2015
 * @copyright Copyright 2003-2022 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
*/ 
define('BOX_TOOLS_MOD_LIST', 'Mod List');
define('FILENAME_MOD_LIST', 'mod_list'); 

DELETE FROM admin_pages WHERE page_key = 'mod_list'; 
DELETE FROM admin_pages_to_profiles WHERE page_key = 'mod_list'; 

<?php
class PluginInstaller extends BasePluginInstaller
{
}

<?php

define('HTTP_SERVER', 'http://127.0.0.1:8080');

define('DB_SERVER', '127.0.0.1');  // address of your db server
define('DB_SERVER_USERNAME', 'root');
define('DB_SERVER_PASSWORD', '');
define('DB_DATABASE', 'zencart_test');

define('DB_TYPE', 'mysql');
define('DB_CHARSET', 'utf8mb4');

define('DEVELOPER_MODE', true);

define('ADMIN_NAME', 'Admin');
define('ADMIN_EMAIL', 'test@zencart.test');

define('USE_PCONNECT', false);

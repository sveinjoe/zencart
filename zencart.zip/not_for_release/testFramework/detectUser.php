<?php
$user = $_SERVER['USER'] ?? $_SERVER['MY_USER'];
echo 'Detected User - ' . $user  ."\n";


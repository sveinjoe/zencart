<?php
define('DB_TYPE', 'mysql'); // always 'mysql'
define('DB_PREFIX', 'zen_'); // prefix for database table names -- preferred to be left empty
define('DB_CHARSET', 'utf8mb4'); // 'utf8mb4' or older 'utf8' / 'latin1' are most common
define('DB_SERVER', 'localhost');  // address of your db server
define('DB_SERVER_USERNAME', 'zencart158a_com');
define('DB_SERVER_PASSWORD', 'zencart158a_pass');
define('DB_DATABASE', 'zencart158a_com');
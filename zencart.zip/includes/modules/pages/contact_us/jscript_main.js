jQuery(document).ready(function() {
    jQuery('#send-to option[value=""]').attr('disabled', true);
});
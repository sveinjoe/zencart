<?php

/* This file is purposely left blank.
 *
 * This file existed in previous versions of the module. When installing the
 * current version of this module this file should be removed from the
 * installation. When upgrading from a previous version the end user can
 * simply replace (overwrite) the current file with this "blank" file.
 * If uploaded, the install / upgrade script removes this file automatially.
 *
 * This file is included in the distribution to make upgrades easier during
 * the process of copying files from the distribution to a Zen Cart
 * installation.
 */

<?php
$define = [
    'NAVBAR_TITLE_1' => 'Search',
    'NAVBAR_TITLE_2' => 'Search Results',
    'HEADING_TITLE' => 'Search',
    'HEADING_SEARCH_CRITERIA' => 'Search Criteria',
    'ENTRY_CATEGORIES' => 'Categories:',
    'ENTRY_MANUFACTURERS' => 'Manufacturers:',
    'TABLE_HEADING_IMAGE' => '',
    'TEXT_NO_PRODUCTS' => 'There is no product that matches the search criteria.',
    'TEXT_SHOW' => 'Filter Results by:',
];

return $define;

<?php
$define = [
    'NAVBAR_TITLE' => 'Page 3',
    'HEADING_TITLE' => 'Page 3',
    'TEXT_INFORMATION' => 'Page 3 text goes here.',
];

return $define;
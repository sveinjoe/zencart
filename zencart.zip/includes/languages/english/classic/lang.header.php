<?php
$define = [
    'HEADER_TITLE_MY_ACCOUNT' => 'My Account',
    'HEADER_TITLE_CART_CONTENTS' => 'Shopping Cart',
    'HEADER_TITLE_CHECKOUT' => 'Checkout',
    'HEADER_TITLE_CATALOG' => 'Home',
    'HEADER_TITLE_LOGOFF' => 'Log Out',
    'HEADER_TITLE_LOGIN' => 'Log In',
    'HEADER_ALT_TEXT' => 'Powered by Zen Cart :: The Art of E-Commerce',
    'HEADER_SALES_TEXT' => '<h1>Sales Message Goes Here</h1>',
    'HEADER_LOGO_WIDTH' => '100%',
    'HEADER_LOGO_HEIGHT' => 'auto',
    'HEADER_LOGO_IMAGE' => 'logo.gif',
    'HEADER_SEARCH_BUTTON' => 'Search',
    'HEADER_SEARCH_DEFAULT_TEXT' => 'Enter search keywords here',
    'SEARCH_DEFAULT_TEXT' => 'search here',
];

return $define;

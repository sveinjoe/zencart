<?php
$define = [
    'NAVBAR_TITLE_1' => 'My Account',
    'NAVBAR_TITLE_2' => 'Newsletter Subscriptions',
    'HEADING_TITLE' => 'Newsletter Subscriptions',
    'MY_NEWSLETTERS_GENERAL_NEWSLETTER' => 'General Newsletter',
    'MY_NEWSLETTERS_GENERAL_NEWSLETTER_DESCRIPTION' => 'Including store news, new products, special offers, and other promotional announcements.',
    'SUCCESS_NEWSLETTER_UPDATED' => 'Your newsletter subscriptions have been updated.',
];

return $define;
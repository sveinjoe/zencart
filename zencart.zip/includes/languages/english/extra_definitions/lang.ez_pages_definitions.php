<?php
$define = [
    'BOX_HEADING_EZPAGES' => 'Important Links',
    'TEXT_EZ_PAGES_TABLE_CONTEXT' => 'Table of Contents',
    'CURRENT_PAGE_INDICATOR' => '&nbsp;*&nbsp;',
    'NOT_CURRENT_PAGE_INDICATOR' => '&nbsp;-&nbsp;',
];

return $define;
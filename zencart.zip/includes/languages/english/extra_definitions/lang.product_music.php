<?php
$define = [
    'BOX_HEADING_MUSIC_GENRES' => 'Music Genres',
    'BOX_HEADING_RECORD_COMPANY' => 'Record Companies',
    'PULL_DOWN_RECORD_COMPANIES' => '- Reset -',
    'PULL_DOWN_MUSIC_GENRES' => '- Reset -',
];

return $define;
<?php
$define = [
    'TEXT_COUPON_HELP_NAME' => '<br><br>Coupon Name: %s',
    'TEXT_COUPON_HELP_FIXED' => '<br><br>The coupon is worth %s discount against your order',
    'TEXT_COUPON_HELP_FREESHIP' => '<br><br>This coupon gives you free shipping on your order',
    'TEXT_COUPON_HELP_DESC' => '<br><br>Coupon Description: %s',
    'TEXT_COUPON_HELP_RESTRICT' => '<br><br>Product/Category Restrictions',
    'TEXT_COUPON_HELP_CATEGORIES' => 'Category',
    'TEXT_COUPON_HELP_PRODUCTS' => 'Product',
    'TEXT_ALLOWED' => ' (Allowed)',
    'TEXT_DENIED' => ' (Denied)',
];

return $define;

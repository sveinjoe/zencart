<?php
$define = [
    'NAVBAR_TITLE_1' => 'My Account',
    'NAVBAR_TITLE_2' => 'Change Password',
    'HEADING_TITLE' => 'My Password',
    'SUCCESS_PASSWORD_UPDATED' => 'Your password has been successfully updated.',
    'ERROR_CURRENT_PASSWORD_NOT_MATCHING' => 'Your Current Password did not match the password in our records. Please try again.',
];

return $define;
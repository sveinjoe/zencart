<?php
$define = [
    'NAVBAR_TITLE' => 'New Products',
    'HEADING_TITLE' => 'New Products',
];

return $define;

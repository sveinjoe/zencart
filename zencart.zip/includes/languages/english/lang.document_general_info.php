<?php
$define = [
];

return $define;

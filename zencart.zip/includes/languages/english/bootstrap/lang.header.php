<?php
$define = [
    'HEADER_TITLE_MY_ACCOUNT' => 'My Account',
    'HEADER_TITLE_CART_CONTENTS' => 'Shopping Cart',
    'HEADER_TITLE_CHECKOUT' => 'Checkout',
    'HEADER_TITLE_CATALOG' => 'Home',
    'HEADER_TITLE_LOGOFF' => 'Log Out',
    'HEADER_TITLE_LOGIN' => 'Log In',
    'HEADER_SALES_TEXT' => 'TagLine Here',
    'HEADER_ALT_TEXT' => 'Powered by Zen Cart :: The Art of E-Commerce',
    'HEADER_LOGO_IMAGE' => 'logo.gif',
    'HEADER_LOGO_WIDTH' => '254',
    'HEADER_LOGO_HEIGHT' => '68',
    'HEADER_SEARCH_BUTTON' => '<i class="fas fa-search"></i>',
    'HEADER_SEARCH_DEFAULT_TEXT' => 'Enter search keywords here',
    'SEARCH_DEFAULT_TEXT' => 'search here',
];

return $define;

<?php
$define = [
    'NAVBAR_TITLE' => 'Site Map',
    'HEADING_TITLE' => 'Site Map',
    'TEXT_INFORMATION' => '',
];

return $define;

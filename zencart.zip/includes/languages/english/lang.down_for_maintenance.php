<?php
$define = [
    'NAVBAR_TITLE' => 'Down for Maintenance',
    'HEADING_TITLE' => 'Down for Maintenance ...',
    'DOWN_FOR_MAINTENANCE_TEXT_INFORMATION' => 'The site is currently down for maintenance. Please excuse the dust, and try back later.',
    'TEXT_MAINTENANCE_ON_AT_TIME' => 'The Admin / Webmaster has enabled maintenance at : ',
    'TEXT_MAINTENANCE_PERIOD' => 'Maintenance period: ',
    'DOWN_FOR_MAINTENANCE_STATUS_TEXT' => 'To verify the site status ... Click here:',
];

return $define;
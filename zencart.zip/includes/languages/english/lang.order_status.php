<?php
$define = [
    'NAVBAR_TITLE' => 'Order Status',
    'NAVBAR_TITLE_1' => 'My Account',
    'HEADING_TITLE' => 'Check Order History',
];

return $define;
<?php
$define = [
    'NAVBAR_TITLE_1' => 'My Account',
    'NAVBAR_TITLE_2' => 'Edit Account',
    'HEADING_TITLE' => 'My Account Information',
    'SUCCESS_ACCOUNT_UPDATED' => 'Your account has been successfully updated.',
];

return $define;
<?php
$define = [
    'NAVBAR_TITLE' => 'Featured Products',
    'HEADING_TITLE' => 'Featured Products',
];

return $define;

<?php
$define = [
    'NAVBAR_TITLE' => 'Page 4',
    'HEADING_TITLE' => 'Page 4',
    'TEXT_INFORMATION' => 'Page 4 information goes here.',
];

return $define;
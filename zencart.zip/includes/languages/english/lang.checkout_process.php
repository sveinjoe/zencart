<?php
$define = [
    'EMAIL_TEXT_SUBJECT' => 'Order Confirmation',
    'EMAIL_TEXT_HEADER' => 'Order Confirmation',
    'EMAIL_TEXT_FROM' => ' from ',
    'EMAIL_THANKS_FOR_SHOPPING' => 'Thanks for shopping with us today!',
    'EMAIL_DETAILS_FOLLOW' => 'The following are the details of your order.',
    'EMAIL_TEXT_ORDER_NUMBER' => 'Order Number:',
    'EMAIL_TEXT_INVOICE_URL' => 'Order Details:',
    'EMAIL_TEXT_INVOICE_URL_CLICK' => 'Click here for Order Details',
    'EMAIL_TEXT_DATE_ORDERED' => 'Date Ordered:',
    'EMAIL_TEXT_PRODUCTS' => 'Products',
    'EMAIL_TEXT_DELIVERY_ADDRESS' => 'Delivery Address',
    'EMAIL_TEXT_BILLING_ADDRESS' => 'Billing Address',
    'EMAIL_TEXT_PAYMENT_METHOD' => 'Payment Method',
    'EMAIL_SEPARATOR' => '------------------------------------------------------',
    'EMAIL_ORDER_NUMBER_SUBJECT' => ' No: ',
];

return $define;

<?php

$define = [
    'MODULE_PAYMENT_COD_TEXT_TITLE' => 'Cash on Delivery',
    'MODULE_PAYMENT_COD_TEXT_DESCRIPTION' => 'Cash on Delivery',
];

return $define;

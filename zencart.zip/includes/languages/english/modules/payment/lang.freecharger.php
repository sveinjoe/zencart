<?php
$define = [
    'MODULE_PAYMENT_FREECHARGER_TEXT_TITLE' => 'Free Order',
    'MODULE_PAYMENT_FREECHARGER_TEXT_DESCRIPTION' => 'There is no charge for this order. Typically used for granting Free Shipping. Required to allow no-charge checkouts. Required for free downloads.',
    'MODULE_PAYMENT_FREECHARGER_TEXT_EMAIL_FOOTER' => 'There is no charge for this order.',
];

return $define;

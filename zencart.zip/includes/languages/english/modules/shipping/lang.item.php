<?php
$define = [
    'MODULE_SHIPPING_ITEM_TEXT_TITLE' => 'Per Item',
    'MODULE_SHIPPING_ITEM_TEXT_DESCRIPTION' => 'Per Item',
    'MODULE_SHIPPING_ITEM_TEXT_WAY' => 'Best Way',
];

return $define;
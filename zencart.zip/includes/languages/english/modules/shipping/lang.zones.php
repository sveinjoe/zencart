<?php
$define = [
    'MODULE_SHIPPING_ZONES_TEXT_TITLE' => 'Zone Rates',
    'MODULE_SHIPPING_ZONES_TEXT_DESCRIPTION' => 'Zone Based Rates',
    'MODULE_SHIPPING_ZONES_TEXT_WAY' => 'Shipping to',
    'MODULE_SHIPPING_ZONES_INVALID_ZONE' => 'No shipping available to the selected country',
    'MODULE_SHIPPING_ZONES_UNDEFINED_RATE' => 'The shipping rate cannot be determined at this time',
];

return $define;
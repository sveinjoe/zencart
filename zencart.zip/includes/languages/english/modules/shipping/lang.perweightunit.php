<?php
$define = [
    'MODULE_SHIPPING_PERWEIGHTUNIT_TEXT_TITLE' => 'Per Unit',
    'MODULE_SHIPPING_PERWEIGHTUNIT_TEXT_DESCRIPTION' => 'Per Unit',
    'MODULE_SHIPPING_PERWEIGHTUNIT_TEXT_WAY' => 'Best Way',
];

return $define;

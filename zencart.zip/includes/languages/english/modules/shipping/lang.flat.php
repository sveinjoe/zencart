<?php
$define = [
    'MODULE_SHIPPING_FLAT_TEXT_TITLE' => 'Flat Rate',
    'MODULE_SHIPPING_FLAT_TEXT_DESCRIPTION' => 'Flat Rate',
    'MODULE_SHIPPING_FLAT_TEXT_WAY' => 'Best Way',
];

return $define;
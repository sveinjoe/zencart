<?php
$define = [
    'MODULE_SHIPPING_TABLE_TEXT_TITLE' => 'Table Rate',
    'MODULE_SHIPPING_TABLE_TEXT_DESCRIPTION' => 'Table Rate',
    'MODULE_SHIPPING_TABLE_TEXT_WAY' => 'Best Way',
];

return $define;
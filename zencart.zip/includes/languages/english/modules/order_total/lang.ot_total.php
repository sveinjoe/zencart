<?php
$define = [
    'MODULE_ORDER_TOTAL_TOTAL_TITLE' => 'Total',
    'MODULE_ORDER_TOTAL_TOTAL_DESCRIPTION' => 'Order Total',
];

return $define;

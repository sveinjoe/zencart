<?php
$define = [
    'MODULE_ORDER_TOTAL_COD_TITLE' => 'COD Fee',
    'MODULE_ORDER_TOTAL_COD_DESCRIPTION' => 'COD Fee',
    'TEXT_INFO_COD_FEES' => '<strong>Note:</strong> COD fees may apply',
];

return $define;

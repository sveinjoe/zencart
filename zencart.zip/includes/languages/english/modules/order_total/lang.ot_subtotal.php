<?php
$define = [
    'MODULE_ORDER_TOTAL_SUBTOTAL_TITLE' => 'Sub-Total',
    'MODULE_ORDER_TOTAL_SUBTOTAL_DESCRIPTION' => 'Order Sub-Total',
];

return $define;

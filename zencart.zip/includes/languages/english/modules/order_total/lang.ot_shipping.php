<?php
// FIXME - move the last two strings into a shared file in next update
$define = [
    'MODULE_ORDER_TOTAL_SHIPPING_TITLE' => 'Shipping',
    'MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION' => 'Order Shipping Cost',
    'FREE_SHIPPING_TITLE' => 'Free Shipping',
    'FREE_SHIPPING_DESCRIPTION' => 'Free shipping for orders over %s',
];

return $define;

<?php
$define = [
    'MODULE_ORDER_TOTAL_LOWORDERFEE_TITLE' => 'Low Order Fee',
    'MODULE_ORDER_TOTAL_LOWORDERFEE_DESCRIPTION' => 'Low Order Fee',
];

return $define;

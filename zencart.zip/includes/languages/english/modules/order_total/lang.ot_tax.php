<?php
$define = [
    'MODULE_ORDER_TOTAL_TAX_TITLE' => 'Tax',
    'MODULE_ORDER_TOTAL_TAX_DESCRIPTION' => 'Order Tax',
];

return $define;

<?php
$define = [
    'BOX_HEADING_WHOS_ONLINE' => 'Who\'s Online',
    'BOX_WHOS_ONLINE_THEREIS' => 'There currently is',
    'BOX_WHOS_ONLINE_THEREARE' => 'There currently are',
    'BOX_WHOS_ONLINE_GUEST' => 'guest',
    'BOX_WHOS_ONLINE_GUESTS' => 'guests',
    'BOX_WHOS_ONLINE_AND' => 'and',
    'BOX_WHOS_ONLINE_MEMBER' => 'member',
    'BOX_WHOS_ONLINE_MEMBERS' => 'members',
    'BOX_WHOS_ONLINE_ONLINE' => 'online.',
];

return $define;
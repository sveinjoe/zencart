<?php
$define = [
    'ERROR_CUSTOMER_DOWNLOAD_FAILURE' => 'Customer Download Failure',
];

return $define;
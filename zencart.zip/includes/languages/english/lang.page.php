<?php
$define = [
    'ERROR_PAGE_NOT_FOUND' => 'Sorry, the page you were attempting to access cannot be found.',
];

return $define;
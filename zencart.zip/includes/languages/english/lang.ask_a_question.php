<?php
$define = [
    'NAVBAR_TITLE' => 'Ask a Question',
    'HEADING_TITLE' => 'Ask a Question About ',
    'FORM_TITLE' => 'What is Your Question?',
    'TEXT_SUCCESS' => 'Your message has been successfully sent.',
    'EMAIL_SUBJECT' => 'Product Inquiry at ' . STORE_NAME,
    'TEXT_PRODUCT_NAME' => 'Product Name: ',
];

return $define;

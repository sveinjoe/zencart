<?php
$define = [
    'NAVBAR_TITLE' => 'Customers Authorization Pending',
    'HEADING_TITLE' => 'Customer Authorization Pending ...',
    'CUSTOMERS_AUTHORIZATION_TEXT_INFORMATION' => 'Thank you for requesting Authorization for our store.<br><br>We will contact you as soon as possible.',
    'CUSTOMERS_AUTHORIZATION_STATUS_TEXT' => 'To verify your Authorization status ... Click here:',
];

return $define;
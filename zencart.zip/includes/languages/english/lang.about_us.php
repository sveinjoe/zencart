<?php
$define = [
    'NAVBAR_TITLE' => 'About Us',
    'HEADING_TITLE' => 'About Us',
];

return $define;

<?php
$define = [
    'NAVBAR_TITLE_1' => 'Checkout - Step 3',
    'NAVBAR_TITLE_2' => 'Order Confirmation',
    'HEADING_TITLE' => 'Step 3 of 3 - Order Confirmation',
    'HEADING_PRODUCTS' => 'Shopping Cart Contents',
    'NO_COMMENTS_TEXT' => 'None',
    'TITLE_CONTINUE_CHECKOUT_PROCEDURE' => 'Final Step',
    'TEXT_CONTINUE_CHECKOUT_PROCEDURE' => '- continue to complete your order. Thank you!',
];

return $define;

<?php
$define = [
    'NAVBAR_TITLE' => 'Your Download ...',
    'HEADING_TITLE' => 'Your Download ...',
    'TEXT_INFORMATION' => 'Sorry, your download has expired.<br><br>
  If you had other downloads and wish to retrieve them,
  please go to your <a href="' . zen_href_link(FILENAME_ACCOUNT) . '">My Account</a> page to view your order.<br><br>
  Or if you believe that there is a problem with your order, please <a href="' . zen_href_link(FILENAME_CONTACT_US) . '">Contact Us</a> <br><br>
  Thank you!
  ',
];

return $define;

<?php
$define = [
    'NAVBAR_TITLE' => 'Brands',
    'HEADING_TITLE' => 'Shop By Brand',
    'BREADCRUMB_BRANDS' => 'Shop By Brand',
    'FEATURED_BRANDS' => 'Featured Brands',
    'OTHER_BRANDS' => 'Related Brands',
    'NO_BRANDS_AVAILABLE' => 'No brands are currently active for this store.',
];

return $define;
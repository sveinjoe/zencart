<?php
// -----
// Part of the One-Page Checkout plugin, provided under GPL 2.0 license by lat9 (cindy@vinosdefrutastropicales.com).
// Copyright (C) 2013-2022, Vinos de Frutas Tropicales.  All rights reserved.
//
// Last updated for OPC v2.4.2.
//
$define = [
    'EMAIL_TEXT_INVOICE_URL_GUEST' => 'Check order status:',
    'EMAIL_TEXT_INVOICE_URL_CLICK_GUEST' => 'Click here to check your order\'s status',
];
return $define;

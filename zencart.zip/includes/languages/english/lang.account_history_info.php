<?php
$define = [
    'NAVBAR_TITLE' => 'My Account',
    'NAVBAR_TITLE_1' => 'My Account',
    'NAVBAR_TITLE_2' => 'History',
    'NAVBAR_TITLE_3' => 'Order #%s',
    'HEADING_TITLE' => 'Order Information',
];

return $define;

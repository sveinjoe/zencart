<?php
$define = [
    'NAVBAR_TITLE' => 'Reviews',
];

return $define;

<?php
$define = [
    'NAVBAR_TITLE' => 'Page 2',
    'HEADING_TITLE' => 'Page 2',
    'TEXT_INFORMATION' => 'Page 2 information goes here.',
];

return $define;
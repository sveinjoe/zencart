<p>
    Your shopping cart contents are shown below. You may update quantities or remove items by clicking on the related buttons.
    
    If relevant, Shipping, Taxes and Discounts will be determined and displayed during Checkout.
    
    You may of course add more items to your cart!
</p>

<a href="https://docs.zen-cart.com/user/" target="_blank" rel="noopener"><img src="images/large/zencart-docs.jpg" alt="Zen Cart Documentation" title="View the online Zen Cart documentation!" class="home-image" width="100%"></a>
<p>This text is located in the file at: <code> /languages/english/html_includes/classic/define_main_page.php</code></p>
<p>You can quickly edit this content (and remove this image) via Admin->Tools->Define Pages Editor, and select define_main_page from the pulldown.</p>
<p><strong>NOTE: Always backup the files in<code> /languages/english/html_includes/your_template</code></strong></p>

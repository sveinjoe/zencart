<p><strong>Checkout Success Sample Text ...</strong></p
><p>A few words about the approximate shipping time or our processing policy should be put here. </p>
<p>We haven't updated this page yet. Please use the Contact Us form to let us know!</p>

<?php
$define = [
    'NAVBAR_TITLE' => 'Shipping &amp; Returns',
    'HEADING_TITLE' => 'Shipping &amp; Returns',
    'TEXT_INFORMATION' => 'Your Shipping &amp; Returns policy should be added here.',
];

return $define;
<?php
$define = [
    'HEADING_TITLE' => 'Contact Us',
    'NAVBAR_TITLE' => 'Contact Us',
    'TEXT_SUCCESS' => 'Your message has been successfully sent.',
    'EMAIL_SUBJECT' => 'Website Inquiry from ' . STORE_NAME,
];

return $define;

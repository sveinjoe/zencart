<?php
$define = [
    'NAVBAR_TITLE' => 'All Products',
    'HEADING_TITLE' => 'All Products',
];

return $define;

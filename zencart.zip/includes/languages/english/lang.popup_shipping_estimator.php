<?php
$define = [
    'HEADING_SEARCH_HELP' => 'Shipping Estimator:',
];

return $define;

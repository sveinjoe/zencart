<?php
$define = [
    'NAVBAR_TITLE' => 'Privacy Notice',
    'HEADING_TITLE' => 'Privacy Notice',
    'TEXT_INFORMATION' => 'Your Privacy Notice should be on this page.',
];

return $define;
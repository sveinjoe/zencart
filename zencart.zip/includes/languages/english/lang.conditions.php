<?php
$define = [
    'NAVBAR_TITLE' => 'Conditions of Use',
    'HEADING_TITLE' => 'Conditions of Use',
    'TEXT_INFORMATION' => 'Your Conditions of Use information should be on this page.',
];

return $define;
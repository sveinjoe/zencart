<?php
$define = [
    'NAVBAR_TITLE' => 'Specials',
    'HEADING_TITLE' => 'Specials',
];

return $define;
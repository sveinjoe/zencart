<?php
$define = [
    'TEXT_RECORD_COMPANY_URL' => 'For more information, please visit the Record Company\'s <a href="%s" rel="noreferrer noopener" target="_blank">webpage</a>.',
    'TEXT_PRODUCT_ARTIST' => 'Artist: ',
    'TEXT_PRODUCT_MUSIC_GENRE' => 'Music Genre: ',
    'TEXT_PRODUCT_COLLECTIONS' => 'Media Collection: ',
];

return $define;

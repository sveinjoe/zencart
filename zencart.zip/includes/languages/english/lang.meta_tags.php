<?php
$define = [
    'TITLE' => 'Zen Cart!',
    'SITE_TAGLINE' => 'The Art of E-commerce',
    'CUSTOM_KEYWORDS' => 'ecommerce, open source, shop, online shopping, store',
    'HOME_PAGE_META_DESCRIPTION' => '',
    'HOME_PAGE_META_KEYWORDS' => '',
    'HOME_PAGE_TITLE' => '',
    'META_TAGS_REVIEW' => 'Reviews: ',
    'PRIMARY_SECTION' => ' : ',
    'SECONDARY_SECTION' => ' - ',
    'TERTIARY_SECTION' => ', ',
    'METATAGS_DIVIDER' => ' ',
];

return $define;

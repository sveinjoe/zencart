<?php
/** 
 * File contains just the notifier class
 *
 * @copyright Copyright 2003-2022 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: DrByte 2020 Jul 10 Modified in v1.5.8-alpha $
 */
/**
 * class notifier is a concrete implemetation of the abstract base class
 *
 * it can be used in procedural (non OOP) code to set up an observer
 * see the observer/notifier tutorial for more details.
 *
 */
if (!defined('IS_ADMIN_FLAG')) {
  die('Illegal Access');
}
class notifier extends base {
}
?>
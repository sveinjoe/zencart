<?php
// we use php file for now, we will later move to using yaml or another format
$libs['jquery.livequery'] = array(
	'1.1.1' => array(
		'jscript_files' => array(
			'livequery.js' => array(
				'local' => 'livequery.js', 
			)
		)
	)
);
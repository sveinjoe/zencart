<?php
// we use php file for now, we will later move to using yaml or another format
$libs['jquery.includeMany'] = array(
	'1.2.2' => array(
		'jscript_files' => array(
			'includeMany.js' => array(
				'local' => 'includeMany.js', 
			)
		)
	)
);
<?php
// we use php file for now, we will later move to using yaml or another format
$libs['jquery.facebox'] = array(
	'1.3' => array(
		'jscript_files' => array(
			'facebox.js' => array(
				'local' => 'facebox.js', 
			)
		),
		'css_files' => array(
			'facebox.css' => array(
				'local' => 'facebox.css', 
			)
		)
	)
);
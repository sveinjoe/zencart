<?php
// we use php file for now, we will later move to using yaml or another format
$libs['jquery.form'] = array(
	'2.63' => array(
		'jscript_files' => array(
			'form.js' => array(
				'local' => 'form.js', 
			)
		)
	),
	'2.84' => array(
		'jscript_files' => array(
			'form.js' => array(
				'local' => 'form.js', 
			)
		)
	)
);
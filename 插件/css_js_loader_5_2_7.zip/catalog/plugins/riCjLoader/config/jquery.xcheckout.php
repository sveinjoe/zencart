<?php
// we use php file for now, we will later move to using yaml or another format
$libs['jquery.xcheckout'] = array(
	'3.0' => array(
		'jscript_files' => array(
			'xcheckout.js' => array(
				'local' => 'xcheckout.js', 
			)
		)
	)
);
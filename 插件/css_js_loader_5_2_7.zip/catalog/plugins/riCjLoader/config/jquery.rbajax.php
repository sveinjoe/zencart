<?php
// we use php file for now, we will later move to using yaml or another format
$libs['jquery.rbajax'] = array(
	'1.0' => array(
		'jscript_files' => array(
			'rbajax.js' => array(
				'local' => 'rbajax.js', 
			)
		)
	),
	'2.0' => array(
		'jscript_files' => array(
			'rbajax.js' => array(
				'local' => 'rbajax.js', 
			)
		)
	)
);
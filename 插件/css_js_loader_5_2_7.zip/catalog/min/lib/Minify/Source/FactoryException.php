<?php

class Minify_Source_FactoryException extends Exception
{
}

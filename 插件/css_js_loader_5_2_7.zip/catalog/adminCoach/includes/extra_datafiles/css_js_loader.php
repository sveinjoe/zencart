<?php
  define('BOX_CONFIGURATION_CSS_JS_LOADER', 'CSS/JS Loader Configuration'); 
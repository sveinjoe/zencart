<?php 
// Fix bug on defining the order of files loaded by Google Minify
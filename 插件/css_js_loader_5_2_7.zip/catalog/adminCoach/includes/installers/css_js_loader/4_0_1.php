<?php
// Moved core edits from html_header.php to documentation
// Added meta directory
// Defer inline JS, add instructions to doc
// Better Support For FireFox
// Fix installer bug

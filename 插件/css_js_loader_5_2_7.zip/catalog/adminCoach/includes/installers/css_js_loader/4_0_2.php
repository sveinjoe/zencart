<?php
// Embeds correct license in documentation
// removed faulty defer_inline_js.js
// Fixed syntax error
// Update docs for handling inline javascript

<?php
// -----
// Initialization messages used by the ZCAdditions' bootstrap template.
//
define('ZCA_BOOTSTRAP_CONFIG_WARNING', 'Some configuration settings are different from the <em>ZCA bootstrap</em> template\'s defaults.  See %s for details.');
define('ZCA_BOOTSTRAP_SETTINGS_ADDED', 'The following settings were added to support the ZCA <code>bootstrap</code> template: %s');

// -----
// Defines the template's label for its configuration settings' display.
//
define('BOX_ZCA_BOOTSTRAP', 'Bootstrap Template Settings');

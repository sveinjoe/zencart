<?php
/**
 * Include AJAX Framework for non-template_default templates **only**!
 *
 * @package templateSystem
 * @copyright Copyright 2003-2019 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: lat9 2019 Mar 16 Modified in v1.5.6b $
 */
require DIR_WS_TEMPLATES . 'template_default/jscript/jscript_framework.php';

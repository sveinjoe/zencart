<?php
// -----
// Part of the Bootstrap template for Zen Cart.
//
// Bootstrap v3.4.0.
//
// -----
// If present, use the 'template_default' version of the file for non-template_default templates only!
//
$default_file = DIR_WS_TEMPLATES . 'template_default/jscript/jscript_sidebox_select_form.php';
if (is_file($default_file)) {
    require $default_file;
}

<?php
$define = [
    'NAVBAR_TITLE' => 'Page Not Found',
    'HEADING_TITLE' => 'Page Not Found',
    'TEXT_INFORMATION' => '',
];

return $define;

<?php
$define = [
    'BOX_HEADING_DOCUMENT_CATEGORIES' => 'Documents',
];

return $define;
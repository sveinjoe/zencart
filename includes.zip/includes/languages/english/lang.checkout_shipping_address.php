<?php
$define = [
    'NAVBAR_TITLE' => 'Change Shipping Address',
    'NAVBAR_TITLE_1' => 'Checkout',
    'NAVBAR_TITLE_2' => 'Change Shipping Address',
    'HEADING_TITLE' => 'Change the Shipping Address',
    'TITLE_SHIPPING_ADDRESS' => 'Current Shipping Address',
    'TABLE_HEADING_ADDRESS_BOOK_ENTRIES' => '...Or Choose From Your Address Book Entries',
    'TITLE_PLEASE_SELECT' => 'Change the Shipping Address for This Order',
    'TABLE_HEADING_NEW_SHIPPING_ADDRESS' => 'New Shipping Address',
    'TEXT_CREATE_NEW_SHIPPING_ADDRESS' => 'Please use the following form to create a new shipping address for use with this order.',
    'TITLE_CONTINUE_CHECKOUT_PROCEDURE' => 'Continue',
    'TEXT_CONTINUE_CHECKOUT_PROCEDURE' => '- to shipping method.',
];

return $define;

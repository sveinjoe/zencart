<?php
$define = []; 
if (!defined('TEXT_SELECT_AN_OPTION')) {
    $define['TEXT_SELECT_AN_OPTION'] = 'Please Select';
}

return $define;

<?php
$define = [
    'MODULE_ORDER_TOTAL_GROUP_PRICING_TITLE' => 'Group Discount',
    'MODULE_ORDER_TOTAL_GROUP_PRICING_DESCRIPTION' => 'Group Discount',
];

return $define;

<?php
$define = [
    'NAVBAR_TITLE' => 'Reviews',
    'HEADING_TITLE' => 'Reviews',
];

return $define;

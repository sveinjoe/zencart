 if (document.ask_a_question){ if (document.ask_a_question.contactname) {document.ask_a_question.contactname.focus()} };
